# MagazynexApiV1.OneOfPracownikMagazyn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
