# MagazynexApiV1.OneOfTowarMagazyn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
