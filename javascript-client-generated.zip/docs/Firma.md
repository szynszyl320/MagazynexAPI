# MagazynexApiV1.Firma

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**nazwa** | **String** |  | [optional] 
**numerTelefonu** | **String** |  | [optional] 
