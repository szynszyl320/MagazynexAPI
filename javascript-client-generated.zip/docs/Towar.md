# MagazynexApiV1.Towar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firma** | **OneOfTowarFirma** |  | [optional] 
**magazyn** | **OneOfTowarMagazyn** |  | [optional] 
**opisProduktu** | **String** |  | [optional] 
**klasaTowarowNiebezpiecznych** | **String** |  | [optional] 
**cenaNettoZaSztuke** | **Number** |  | [optional] 
**ilosc** | **Number** |  | [optional] 
**nazwaProduktu** | **String** |  | [optional] 
