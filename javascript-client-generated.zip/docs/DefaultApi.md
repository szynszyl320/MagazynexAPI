# MagazynexApiV1.DefaultApi

All URIs are relative to *https://localhost:7098*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteFirmas**](DefaultApi.md#deleteFirmas) | **DELETE** /firmas/{Nazwa} | 
[**deleteMagazyns**](DefaultApi.md#deleteMagazyns) | **DELETE** /magazyns/{Nazwa} | 
[**deletePracowniks**](DefaultApi.md#deletePracowniks) | **DELETE** /pracowniks/{Imie} | 
[**deleteTowarsProduktu**](DefaultApi.md#deleteTowarsProduktu) | **DELETE** /towars/{Nazwa_Produktu} | 
[**getFirmas**](DefaultApi.md#getFirmas) | **GET** /firmas | 
[**getFirmas2**](DefaultApi.md#getFirmas2) | **GET** /firmas/{Nazwa} | 
[**getMagazyns**](DefaultApi.md#getMagazyns) | **GET** /magazyns | 
[**getMagazynsNazwa**](DefaultApi.md#getMagazynsNazwa) | **GET** /magazyns{Nazwa} | 
[**getPracowniks**](DefaultApi.md#getPracowniks) | **GET** /pracowniks | 
[**getPracowniks2**](DefaultApi.md#getPracowniks2) | **GET** /pracowniks/{Imie} | 
[**getTowars**](DefaultApi.md#getTowars) | **GET** /towars | 
[**getTowarsProduktu**](DefaultApi.md#getTowarsProduktu) | **GET** /towars/{Nazwa_Produktu} | 
[**postFirmas**](DefaultApi.md#postFirmas) | **POST** /firmas | 
[**postMagazyns**](DefaultApi.md#postMagazyns) | **POST** /magazyns | 
[**postPracowniks**](DefaultApi.md#postPracowniks) | **POST** /pracowniks | 
[**postTowars**](DefaultApi.md#postTowars) | **POST** /towars | 
[**putFirmas**](DefaultApi.md#putFirmas) | **PUT** /firmas/{Nazwa} | 
[**putMagazyns**](DefaultApi.md#putMagazyns) | **PUT** /magazyns/{Nazwa} | 
[**putPracowniks**](DefaultApi.md#putPracowniks) | **PUT** /pracowniks/{Imie} | 
[**putTowarsProduktu**](DefaultApi.md#putTowarsProduktu) | **PUT** /towars/{Nazwa_Produktu} | 

<a name="deleteFirmas"></a>
# **deleteFirmas**
> deleteFirmas(nazwa)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let nazwa = "nazwa_example"; // String | 

apiInstance.deleteFirmas(nazwa, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nazwa** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="deleteMagazyns"></a>
# **deleteMagazyns**
> deleteMagazyns(nazwa)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let nazwa = "nazwa_example"; // String | 

apiInstance.deleteMagazyns(nazwa, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nazwa** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="deletePracowniks"></a>
# **deletePracowniks**
> deletePracowniks(imie)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let imie = "imie_example"; // String | 

apiInstance.deletePracowniks(imie, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **imie** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="deleteTowarsProduktu"></a>
# **deleteTowarsProduktu**
> deleteTowarsProduktu(nazwaProduktu)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let nazwaProduktu = "nazwaProduktu_example"; // String | 

apiInstance.deleteTowarsProduktu(nazwaProduktu, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nazwaProduktu** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getFirmas"></a>
# **getFirmas**
> getFirmas()



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
apiInstance.getFirmas((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getFirmas2"></a>
# **getFirmas2**
> getFirmas2(nazwa)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let nazwa = "nazwa_example"; // String | 

apiInstance.getFirmas2(nazwa, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nazwa** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getMagazyns"></a>
# **getMagazyns**
> getMagazyns()



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
apiInstance.getMagazyns((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getMagazynsNazwa"></a>
# **getMagazynsNazwa**
> getMagazynsNazwa(nazwa)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let nazwa = "nazwa_example"; // String | 

apiInstance.getMagazynsNazwa(nazwa, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nazwa** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getPracowniks"></a>
# **getPracowniks**
> getPracowniks()



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
apiInstance.getPracowniks((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getPracowniks2"></a>
# **getPracowniks2**
> getPracowniks2(imie)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let imie = "imie_example"; // String | 

apiInstance.getPracowniks2(imie, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **imie** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getTowars"></a>
# **getTowars**
> getTowars()



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
apiInstance.getTowars((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getTowarsProduktu"></a>
# **getTowarsProduktu**
> getTowarsProduktu(nazwaProduktu)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let nazwaProduktu = "nazwaProduktu_example"; // String | 

apiInstance.getTowarsProduktu(nazwaProduktu, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nazwaProduktu** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postFirmas"></a>
# **postFirmas**
> postFirmas(body)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Firma(); // Firma | 

apiInstance.postFirmas(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Firma**](Firma.md)|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="postMagazyns"></a>
# **postMagazyns**
> postMagazyns(body)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Magazyn(); // Magazyn | 

apiInstance.postMagazyns(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Magazyn**](Magazyn.md)|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="postPracowniks"></a>
# **postPracowniks**
> postPracowniks(body)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Pracownik(); // Pracownik | 

apiInstance.postPracowniks(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Pracownik**](Pracownik.md)|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="postTowars"></a>
# **postTowars**
> postTowars(body)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Towar(); // Towar | 

apiInstance.postTowars(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Towar**](Towar.md)|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="putFirmas"></a>
# **putFirmas**
> putFirmas(body, nazwa)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Firma(); // Firma | 
let nazwa = "nazwa_example"; // String | 

apiInstance.putFirmas(body, nazwa, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Firma**](Firma.md)|  | 
 **nazwa** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="putMagazyns"></a>
# **putMagazyns**
> putMagazyns(body, nazwa)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Magazyn(); // Magazyn | 
let nazwa = "nazwa_example"; // String | 

apiInstance.putMagazyns(body, nazwa, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Magazyn**](Magazyn.md)|  | 
 **nazwa** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="putPracowniks"></a>
# **putPracowniks**
> putPracowniks(body, imie)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Pracownik(); // Pracownik | 
let imie = "imie_example"; // String | 

apiInstance.putPracowniks(body, imie, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Pracownik**](Pracownik.md)|  | 
 **imie** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="putTowarsProduktu"></a>
# **putTowarsProduktu**
> putTowarsProduktu(body, nazwaProduktu)



### Example
```javascript
import {MagazynexApiV1} from 'magazynex_api_v1';

let apiInstance = new MagazynexApiV1.DefaultApi();
let body = new MagazynexApiV1.Towar(); // Towar | 
let nazwaProduktu = "nazwaProduktu_example"; // String | 

apiInstance.putTowarsProduktu(body, nazwaProduktu, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Towar**](Towar.md)|  | 
 **nazwaProduktu** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

