# MagazynexApiV1.OneOfTowarFirma

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
