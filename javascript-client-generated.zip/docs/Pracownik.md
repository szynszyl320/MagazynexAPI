# MagazynexApiV1.Pracownik

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**imie** | **String** |  | [optional] 
**nazwisko** | **String** |  | [optional] 
**stanowisko** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**numerTelefonu** | **Number** |  | [optional] 
**magazyn** | **OneOfPracownikMagazyn** |  | [optional] 
