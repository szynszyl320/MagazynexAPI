# MagazynexApiV1.Magazyn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**pracownicy** | [**[Pracownik]**](Pracownik.md) |  | [optional] 
**lokalizacja** | **String** |  | [optional] 
**nazwa** | **String** |  | [optional] 
